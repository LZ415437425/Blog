//
//  ViewController2.swift
//  UnwindSegue
//
//  Created by 童进 on 15/10/20.
//  Copyright © 2015年 qefee. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func unwindFrom3To2(segue: UIStoryboardSegue) {
        let id = segue.identifier
        let sourceVC = segue.sourceViewController
        let destinationVC = segue.destinationViewController
        
        print("ViewController1 \(id) \(sourceVC) \(destinationVC)")
    }
    
    @IBAction func unwindFrom4To2(segue: UIStoryboardSegue) {
        let id = segue.identifier
        let sourceVC = segue.sourceViewController
        let destinationVC = segue.destinationViewController
        
        print("ViewController1 \(id) \(sourceVC) \(destinationVC)")
    }
}
